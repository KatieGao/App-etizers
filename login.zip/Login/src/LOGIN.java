import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class LOGIN {
	public static int verify(String username, String password) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		int result = 3;
		String searchuser = "SELECT * from users WHERE username = ?";
		String search = "SELECT * from users WHERE username = ? AND password = ?";
		
		try {
			conn = DriverManager.getConnection("");
			
			
			ps = conn.prepareStatement(searchuser);
			ps.setString(1, username);
			rs = ps.executeQuery();
			boolean correct = false;
			boolean exist = false;
			
			
			
			while(rs.next()) {
				String usernameVal = rs.getString("username");
				
				
				
				if(username.equals(usernameVal)){
					exist = true;
				}
			}
			ps.close();
			rs.close();
			ps = conn.prepareStatement(search);
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			
			while(rs.next()) {
				String usernameVal = rs.getString("username");
				String passwordVal = rs.getString("password");
				
				if(username.equals(usernameVal) && password.equals(passwordVal)) {
					correct = true;
				}
			}
			if(correct) {
				result = 1;
			}
			else if(exist) {
				result = 2;
			}
			else {
				result = 3;
			}
			}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(rs != null) {
					rs.close();
				}
				if(ps != null) {
					ps.close();
				}
				if(conn != null) {
					conn.close();
				}
			}
			catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
		
		return result;
	}
	
	public static void create(String username, String password) {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String newEntry = "INSERT INTO users (username, password) VALUES (?, ?)";
		try {
			conn = DriverManager.getConnection("");
			
			
			ps = conn.prepareStatement(newEntry);
			ps.setString(1, username);
			ps.setString(2, password);
			ps.executeUpdate();
			
			
			
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(rs != null) {
					rs.close();
				}
				if(ps != null) {
					ps.close();
				}
				if(conn != null) {
					conn.close();
				}
			}
			catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}
		}
		
	}
}
